Zevi Rubin - Program 1
Mark LeBlanc - Comp 116

-Overview-
This program will get random input from a realistic random number generator or from the keyboard. The input is paris of heart rate, and temperature values. The program currently takes three pairs of values and calculates the correlation coefficient between all the data values. It then uses that number to calculate the Strength of Association between the temperature and heart rate input to tell the user if the correlation is Strong or Weak for those particular inputs.

-Documents-
main.cpp
-Contains the main function, most of the calculations, and the outputs.

vitalSigns.cpp
-Contains the functions for taking manual inputs from the keyboard and for generating its own random inputs.

vitalSigns.h
-The header file for reference use that overviews the functions in the viralSigns.cpp file.  

Program Status: Working Flawlessly. Automatic random input is set up, and manual input can be easily configured. 