#include "mp_InputOutput.h"
#include "medPing.h"

//================================================================
// Programmer: 
//
// Summary: 
//
// Modification History:
//    12/15/08 -- (mdl) medPing lives ...
//
//================================================================


int main (int argc, char * const argv[])
{
	medPing_Main();
	
	return 0;
}
