Zevi Rubin - Program 2
Mark LeBlanc - Comp 116

-Overview-
Summary: 
This program will "ping" a chip in the patients body do get vital signs from the patient. 
it will prompt the user to enter the number of sample seconds to take data, and has a built in memory of 5 data sets. The program will then Print out the data for the user and ask the user if they want to delete a vitals record, and delete it then reprint the current record to the screen. 

-Documents-
History_medPing_Main.cpp
	Main document - where functions are called and user input is taken
main.cpp
	calls the medping main function - nothing else
medPing.cpp
	getter file - simulates the chip generating temperature and other data
mp_InputOutput.cpp
	takes input and prepares output - no actual data is processed in this file
mpPatient.cpp
	This is the outline for the patient - includes name, age, etc, sets data to 0
randomBell.cpp
	generates random numbers for use in this simulation
talk2chip.cpp
	this file simulates the chip taking data samples when pinged.  

The following .h files are header for the previous functions. They can be used to view how the functions use the data they take/give.

medping.h
mp_inputoutput.h
mp_normalvitalsign.h
mppatient.h
randombell.h
talk2chip.h

Program Status: Working Flawlessly. Cannot be broken!!! 