Zevi Rubin - Program 3
Mark LeBlanc - Comp 116

-Overview-
Summary: 
This program will generate 5 “jobs” of randomly different types. Each type has a different amount of time it requires to run fully. The user will be prompted to give a time slice, which will be how long the CPU spends on each project as it goes through the queue, and how long the user wants to run the simulation for. Once the user gives a time slice, the program will begin running the jobs. It will only spend the user defined timeslice amount on each job before putting it at the back of the queue and starting the next job. The jobs will pass through this First In First Out style queue until they have all run out of time, and are no longer added back into the queue. As the program accepts each job to the CPU and then passes it out of the queue it will print the name, type, and time remaining value for each job. 

-Documents-

JOB.cpp - this file holds the class JOB and its methods. These are called by main. 

main.cpp - this is where the program is run. All methods are called from here and the queue is initialized here.

The following .h files are header for the previous files. They can be used to view how the functions use the data they take/give.

JOB.h - this file is the header file for above JOB.cpp file. It lets the main.cpp know what methods are present in the class JOB. 


Program Status: Part I is working well. Some development towards part two. Full commenting etc complete. 