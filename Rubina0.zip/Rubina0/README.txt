Zevi Rubin - Program 0
Mark LeBlanc - Comp 116

-overview-
This assignment was to make a program to take three user inputs regarding the values A, B, and C with respect to the quadratic formula: Ax^2 + Bx + C = 0. The program uses the quadratic formula to find the roots of input equation data.
We then created some if/else statements to check if the input is for a single point, horizontal line, linear equation, or a parabola. I also made appropriate result messages that explain the results of the inputs. 

program status: Working Flawlessly for numbers within the limits of sqrt(8 bytes) memory.