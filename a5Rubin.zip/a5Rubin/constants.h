/* constants.h 
   last modified: 4/18/2014
*/

#include <string>
using namespace std;

#ifndef CONSTANTS
#define CONSTANTS
										
const string DEFAULT_TEXT = "junk";

// put more of your constants here




#endif

